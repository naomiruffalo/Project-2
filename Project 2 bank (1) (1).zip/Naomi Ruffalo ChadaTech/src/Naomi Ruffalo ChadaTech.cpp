// Naomi Ruffalo
// Programming Languages

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	//declaring what variables will be named throughout the program
   float initialInv, monthlyDep, annualInt, months, years;
   float totalAmount, initialAmount, firstYearInt;
   //creating the design of the table shown in the example (this one is only the display)
   cout << "********************************" << endl;
   cout << "********** Data Input **********" << endl;
   cout << "Initial Investment Amount: " << endl;
   cout << "Monthly Deposit: " << endl;
   cout << "Annual Interest: " << endl;
   cout << "Number of years: " << endl;
   //creating actual table display with input collected and stored from user
   cout << "********************************" << endl;
   cout << "********** Data Input **********" << endl;
   cout << "Initial Investment Amount: $";
   cin >> initialInv;
   cout << "Monthly Deposit: $";
   cin >> monthlyDep;
   cout << "Annual Interest: %";
   cin >> annualInt;
   cout << "Number of years: ";
   cin >> years;
   months = years * 12;
   //showing third display of balance and interest without monthly deposit
   cout << "Balance and Interest Without Additional Monthly Deposits" << endl;
   cout << "========================================================" << endl;
   cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
   cout << "--------------------------------------------------------" << endl;

   //creating for loop. It'll run until the number of years given is completed
   // it will also add one after every number given the initial value of 0

   for (int i = 0; i < years; i++) {
	   // calculating initial amount is the investment * annual interest in decimal form
       initialAmount = (initialInv) * ((annualInt / 100));
       // giving a value to total amount by adding initial investment amount and endl;
       // the previous initial amount of investment * annual interest in decimal form
       totalAmount = initialInv + initialAmount;
       // printing the number of years first using \t for space then the initial
       // investment amount under "End Balance" and finally using \t to line Initial amount
       // under End Earned Interest
       cout << (i + 1) << "\t\t$" << initialInv << "\t\t$" << initialAmount << endl;
   }
   //showing third display of balance and interest with monthly deposit
   cout << "Balance and Interest With Additional Monthly Deposits" << endl;
   cout << "=====================================================" << endl;
   cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
   cout << "----------------------------------------------------" << endl;

// creating for loop inside for loop so the years can still be shown under "Years" in the table
 for (int i = 0; i < years; i++) {
	   // Set first year interest equal to 0 because we are beginning
       firstYearInt = 0;
    // initial month value is 0. j will run the program throughout each month deposit
    // of the given amount deposit and it will add a month every time
    for (int j = 0; j < 12; j++) {
    	// giving initial amount a value of initial investment + monthly deposit
    	// * annual interest divided by 100 (so it is in decimals) divided by 12
    	// (for 12 months a year)
        initialAmount = (initialInv + monthlyDep) * ((annualInt / 100) / 12);
        // recording initial amount to first year interest additional to the first year interest given
        firstYearInt = firstYearInt + initialAmount;
        // recording initial investment given plus monthly deposit and initial amount
        // in initial investment
        initialInv = initialInv + monthlyDep + initialAmount;
    }
    	// printing years on left, end year balance if deposited monthly, and end earned interest
       cout << (i + 1) << "\t\t$" << initialInv << "\t\t$" << firstYearInt<< endl;
   }

   return 0;
}
